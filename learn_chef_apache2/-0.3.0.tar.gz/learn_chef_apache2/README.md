# learn_chef_apache2

Installs and configures package apache2 and sets a basic home page. This cookbook is used by the Learn Chef tutorials. https://learn.chef.io
